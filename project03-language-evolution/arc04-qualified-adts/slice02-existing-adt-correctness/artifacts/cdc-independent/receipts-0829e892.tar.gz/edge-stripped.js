function NamedFields(firstName, otherValue) {
  return { tag: "NamedFields", firstName: firstName, otherValue: otherValue };
}
const EmptyFields = { tag: "EmptyFields" };
const normalized = (() => {
  const target__gensym0 = NamedFields({ ok: false }, "kept");
  let pattern_field__gensym1;
  let pattern_field__gensym2;
  let pattern_field__gensym3;
  if ((((((((target__gensym0 != null && target__gensym0.tag === "NamedFields") && (pattern_field__gensym1 = target__gensym0.firstName, true)) && typeof pattern_field__gensym1 === "object") && pattern_field__gensym1 !== null) && "ok" in pattern_field__gensym1) && (pattern_field__gensym2 = pattern_field__gensym1.ok, true)) && pattern_field__gensym2 === false) && (pattern_field__gensym3 = target__gensym0.otherValue, true)) {
    const value = pattern_field__gensym3;
    return value;
  }
  {
    return "wrong";
  }
})();
const literalResults = [(() => {
  const t__gensym4 = null;
  if (t__gensym4 === null) {
    return "null";
  } else {
    return "wrong";
  }
})(), (() => {
  const t__gensym5 = false;
  if (t__gensym5 === false) {
    return "false";
  } else {
    return "wrong";
  }
})(), (() => {
  const t__gensym6 = undefined;
  if (t__gensym6 === undefined) {
    return "undefined";
  } else {
    return "wrong";
  }
})(), (() => {
  const t__gensym7 = false;
  if (t__gensym7 === null) {
    return "wrong";
  } else {
    return "null-mismatch";
  }
})(), (() => {
  const t__gensym8 = true;
  if (t__gensym8 === false) {
    return "wrong";
  }
})()];
const outerValue = 99;
const scopeTrace = [];
{
  const target__gensym9 = NamedFields(7, 8);
  let matched__gensym10 = false;
  let pattern_field__gensym11;
  if (!matched__gensym10 && ((target__gensym9 != null && target__gensym9.tag === "NamedFields") && (pattern_field__gensym11 = target__gensym9.firstName, true))) {
    const outerValue = pattern_field__gensym11;
    if (false) {
      matched__gensym10 = true;
      scopeTrace.push("wrong");
    }
  }
  let pattern_field__gensym12;
  if (!matched__gensym10 && ((target__gensym9 != null && target__gensym9.tag === "NamedFields") && (pattern_field__gensym12 = target__gensym9.firstName, true))) {
    const outerValue = pattern_field__gensym12;
    {
      matched__gensym10 = true;
      scopeTrace.push(outerValue);
    }
  }
  if (!matched__gensym10) {
    {
      matched__gensym10 = true;
      scopeTrace.push("wrong");
    }
  }
}
scopeTrace.push(outerValue);
const thrown = new Error("getter-sentinel");
const thrownTarget = { tag: "NamedFields" };
const thrownTrace = [];
Object.defineProperty(thrownTarget, "firstName", { get: () => {
  thrownTrace.push("get");
  throw thrown;
} });
try {
  {
    const target__gensym13 = thrownTarget;
    let matched__gensym14 = false;
    let pattern_field__gensym15;
    if (!matched__gensym14 && ((target__gensym13 != null && target__gensym13.tag === "NamedFields") && (pattern_field__gensym15 = target__gensym13.firstName, true))) {
      const value = pattern_field__gensym15;
      {
        matched__gensym14 = true;
        thrownTrace.push(value);
      }
    }
    if (!matched__gensym14) {
      {
        matched__gensym14 = true;
        thrownTrace.push("fallback");
      }
    }
  }
} catch (caught) {
  thrownTrace.push(caught === thrown);
}
const loopTrace = [];
for (const n of [0, 1, 2]) {
  {
    const target__gensym16 = NamedFields(n, 0);
    let matched__gensym17 = false;
    let pattern_field__gensym18;
    if (!matched__gensym17 && ((target__gensym16 != null && target__gensym16.tag === "NamedFields") && (pattern_field__gensym18 = target__gensym16.firstName, true))) {
      const value = pattern_field__gensym18;
      if (value === 0) {
        matched__gensym17 = true;
        continue;
      }
    }
    let pattern_field__gensym19;
    if (!matched__gensym17 && ((target__gensym16 != null && target__gensym16.tag === "NamedFields") && (pattern_field__gensym19 = target__gensym16.firstName, true))) {
      const value = pattern_field__gensym19;
      if (value === 1) {
        matched__gensym17 = true;
        loopTrace.push(value);
      }
    }
    if (!matched__gensym17) {
      {
        matched__gensym17 = true;
        break;
      }
    }
  }
  loopTrace.push("after");
}
console.log(JSON.stringify([normalized, literalResults, scopeTrace, thrownTrace, loopTrace]));
