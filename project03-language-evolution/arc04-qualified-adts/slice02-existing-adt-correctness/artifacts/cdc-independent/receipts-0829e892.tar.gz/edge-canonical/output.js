function NamedFields(firstName, otherValue) {
  return {
    tag: "NamedFields",
    firstName: firstName,
    otherValue: otherValue
  };
}
const EmptyFields = {
  tag: "EmptyFields"
};
const normalized = (() => {
  const target__gensym0 = NamedFields({
    ok: false
  }, "kept");
  let patternField__gensym0;
  let patternField__gensym1;
  let patternField__gensym2;
  if (target__gensym0 !== null && target__gensym0["tag"] === "NamedFields" && (patternField__gensym0 = target__gensym0["firstName"], true) && typeof patternField__gensym0 === "object" && patternField__gensym0 !== null && ("ok" in patternField__gensym0) && (patternField__gensym1 = patternField__gensym0["ok"], true) && patternField__gensym1 === false && (patternField__gensym2 = target__gensym0["otherValue"], true)) {
    const value = patternField__gensym2;
    return value;
  }
  {
    return "wrong";
  }
})();
const literalResults = [(() => {
  const t__gensym1 = null;
  if (t__gensym1 === null) {
    return "null";
  } else {
    return "wrong";
  }
})(), (() => {
  const t__gensym2 = false;
  if (t__gensym2 === false) {
    return "false";
  } else {
    return "wrong";
  }
})(), (() => {
  const t__gensym3 = undefined;
  if (t__gensym3 === undefined) {
    return "undefined";
  } else {
    return "wrong";
  }
})(), (() => {
  const t__gensym4 = false;
  if (t__gensym4 === null) {
    return "wrong";
  } else {
    return "null-mismatch";
  }
})(), (() => {
  const t__gensym5 = true;
  if (t__gensym5 === false) {
    return "wrong";
  }
})()];
const outerValue = 99;
const scopeTrace = [];
{
  const target__gensym6 = NamedFields(7, 8);
  let matched__gensym7 = false;
  let patternField__gensym3;
  if (!matched__gensym7 && target__gensym6 != null && target__gensym6["tag"] === "NamedFields" && (patternField__gensym3 = target__gensym6["firstName"], true)) {
    const outerValue = patternField__gensym3;
    if (false) {
      matched__gensym7 = true;
      scopeTrace.push("wrong");
    }
  }
  let patternField__gensym4;
  if (!matched__gensym7 && target__gensym6 != null && target__gensym6["tag"] === "NamedFields" && (patternField__gensym4 = target__gensym6["firstName"], true)) {
    const outerValue = patternField__gensym4;
    {
      matched__gensym7 = true;
      scopeTrace.push(outerValue);
    }
  }
  if (!matched__gensym7) {
    {
      matched__gensym7 = true;
      scopeTrace.push("wrong");
    }
  }
}
scopeTrace.push(outerValue);
const thrown = new Error("getter-sentinel");
const thrownTarget = {
  tag: "NamedFields"
};
const thrownTrace = [];
Object.defineProperty(thrownTarget, "firstName", {
  get: () => {
    thrownTrace.push("get");
    throw thrown;
  }
});
try {
  {
    const target__gensym8 = thrownTarget;
    let matched__gensym9 = false;
    let patternField__gensym5;
    if (!matched__gensym9 && target__gensym8 != null && target__gensym8["tag"] === "NamedFields" && (patternField__gensym5 = target__gensym8["firstName"], true)) {
      const value = patternField__gensym5;
      {
        matched__gensym9 = true;
        thrownTrace.push(value);
      }
    }
    if (!matched__gensym9) {
      {
        matched__gensym9 = true;
        thrownTrace.push("fallback");
      }
    }
  }
} catch (caught) {
  thrownTrace.push(caught === thrown);
}
const loopTrace = [];
for (const n of [0, 1, 2]) {
  {
    const target__gensym10 = NamedFields(n, 0);
    let matched__gensym11 = false;
    let patternField__gensym6;
    if (!matched__gensym11 && target__gensym10 != null && target__gensym10["tag"] === "NamedFields" && (patternField__gensym6 = target__gensym10["firstName"], true)) {
      const value = patternField__gensym6;
      if (value === 0) {
        matched__gensym11 = true;
        continue;
      }
    }
    let patternField__gensym7;
    if (!matched__gensym11 && target__gensym10 != null && target__gensym10["tag"] === "NamedFields" && (patternField__gensym7 = target__gensym10["firstName"], true)) {
      const value = patternField__gensym7;
      if (value === 1) {
        matched__gensym11 = true;
        loopTrace.push(value);
      }
    }
    if (!matched__gensym11) {
      {
        matched__gensym11 = true;
        break;
      }
    }
  }
  loopTrace.push("after");
}
console.log(JSON.stringify([normalized, literalResults, scopeTrace, thrownTrace, loopTrace]));

