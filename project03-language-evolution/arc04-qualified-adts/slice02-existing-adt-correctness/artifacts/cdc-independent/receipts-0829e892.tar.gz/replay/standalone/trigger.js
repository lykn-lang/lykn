console.log(21 + 21);
