const home = "/private/tmp/lykn-s02-release-cdc-0829e892";
const source = "/Users/oubiwann/lab/lykn/lang/.worktrees/0.6.x";
const materialized = home + "/direct-xdg/lykn/embedded/0.6.0-compiler-split/packages/lang/";
const names = ["binding.js", "classifier.js", "expander-core.js", "surface-helpers.js", "compiler-private-atoms.js"];
const comparisons = names.map(name => {
  if (typeof name !== "string") {
    throw new TypeError("anonymous: arg 'name' expected string, got " + typeof name);
  }
  const canonical = Deno.readTextFileSync(source + "/packages/lang/" + name);
  const embedded = Deno.readTextFileSync(source + "/crates/lykn-lang/embedded/packages/lang/" + name);
  const delivered = Deno.readTextFileSync(materialized + name);
  if (!(canonical === embedded && canonical === delivered)) {
    throw new Error("module delivery differs: " + name);
  }
  return { name: name, canonicalEqualsEmbedded: true, canonicalEqualsMaterialized: true };
});
const adtExpected = "42\n[7,\"outer\",\"inner\",\"null\",\"missing\",\"literal\",\"safe\",\"false\",\"null\",\"undefined\",9,false,0,\"\",4,6,\"selected\",[\"match: no matching pattern\"],true,true,\"list\",\"safe\",\"bare\",null,false,false,null,\"number\",\"safe\",\"string\",7,\"wildcard\",\"safe\",\"safe\",[\"outer.value\",\"inner.value\",\"wrong.inner.value\"],8,\"wildcard\",[\"object.child\"],[5]]\n";
const hygieneExpected = "[[[[90,91],5,42]],[[90,91],6,42],[[90,91],7,42],[[90,91],8,42],[[90,91],9,42]]\n";
const outputs = [{ name: "adt", expected: adtExpected, actual: Deno.readTextFileSync(home + "/receipts/direct-adt-runtime/stdout.raw") }, { name: "hygiene", expected: hygieneExpected, actual: Deno.readTextFileSync(home + "/receipts/direct-hygiene-runtime/stdout.raw") }];
outputs.forEach(output => {
  if (typeof output !== "object" || output === null) {
    throw new TypeError("anonymous: arg 'output' expected object, got " + typeof output);
  }
  if (!(output.actual === output.expected)) {
    throw new Error("runtime output differs: " + output.name);
  }
});
const evidence = { materialized: materialized, modules: comparisons, outputs: outputs };
Deno.writeTextFileSync(home + "/direct-verification.json", JSON.stringify(evidence, null, 2));
console.log("Five delivery comparisons and two strict native runtime outputs pass");
