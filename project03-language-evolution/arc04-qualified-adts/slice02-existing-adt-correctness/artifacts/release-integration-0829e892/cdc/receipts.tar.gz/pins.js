const home = "/private/tmp/lykn-s02-release-cdc-0829e892";
const source = "/Users/oubiwann/lab/lykn/lang/.worktrees/0.6.x";
const commands = [["git", "status", "--short", "--branch"], ["git", "rev-parse", "HEAD", "HEAD^{tree}"], ["git", "reflog", "-3", "--date=iso", "release/0.6.x"], ["git", "rev-list", "--left-right", "--count", "685bbe1dbbfdaf34ecf49017c22e43f7dc8adb95...HEAD"], ["git", "merge-base", "--is-ancestor", "685bbe1dbbfdaf34ecf49017c22e43f7dc8adb95", "HEAD"], ["git", "diff", "--exit-code", "0829e892999890e8877dec5e35cd249753e1be5d", "HEAD"], ["git", "-C", "/Users/oubiwann/lab/lykn/lang/.worktrees/contract-predicate-lowering", "status", "--short", "--branch"], ["git", "-C", "/Users/oubiwann/lab/lykn/lang/.worktrees/contract-predicate-lowering", "rev-parse", "HEAD", "HEAD^{tree}"], ["git", "log", "--format=%H%n%B", "685bbe1dbbfdaf34ecf49017c22e43f7dc8adb95..HEAD"], ["rustc", "--version"], ["cargo", "--version"], ["deno", "--version"], ["node", "--version"], ["npm", "--version"], ["which", "rustc", "cargo", "deno", "node", "npm"], ["shasum", "-a", "256", "target/release/lykn", "bin/lykn", "/private/tmp/lykn-s02-release-cdc-0829e892/standalone/lykn"], ["shasum", "-a", "256", "target/debug/lykn"]];
const observations = commands.map(argv => {
  if (!Array.isArray(argv)) {
    throw new TypeError("anonymous: arg 'argv' expected array, got " + typeof argv);
  }
  const command = new Deno.Command(argv[0], { args: argv.slice(1), cwd: source, stdout: "piped", stderr: "piped" });
  const result = command.outputSync();
  const decoder = new TextDecoder();
  return { argv: argv, cwd: source, code: result.code, stdout: decoder.decode(result.stdout), stderr: decoder.decode(result.stderr) };
});
Deno.writeTextFileSync(home + "/pins.json", JSON.stringify(observations, null, 2));
console.log(JSON.stringify(observations, null, 2));
