const lyknIntrinsicError0 = Error;
console.log((() => {
  const target__gensym1 = {
    tag: "CDCState",
    decoy: "cold",
    value: "named"
  };
  let patternField__gensym0;
  if (target__gensym1 !== null && target__gensym1["tag"] === "CDCState" && (patternField__gensym0 = Object.values(target__gensym1)[1], true)) {
    const picked = patternField__gensym0;
    return picked;
  }
  throw new lyknIntrinsicError0("match: no matching pattern");
})());
