const lyknIntrinsicError0 = Error;
function CDCScopeCase(value) {
  return {
    tag: "CDCScopeCase",
    value: value
  };
}
const inner = {
  tag: "CDCScopeCase",
  decoy: 9,
  value: 42
};
const outer = {
  tag: "CDCScopeCase",
  decoy: 7,
  value: inner
};
const effects = [];
function select(input) {
  {
    const target__gensym8 = input;
    let matched__gensym9 = false;
    let patternField__gensym0;
    let patternField__gensym1;
    if (!matched__gensym9 && target__gensym8 != null && target__gensym8["tag"] === "CDCScopeCase" && (patternField__gensym0 = target__gensym8["value"], true) && patternField__gensym0 != null && patternField__gensym0["tag"] === "CDCScopeCase" && (patternField__gensym1 = patternField__gensym0["value"], true)) {
      const leaf = patternField__gensym1;
      {
        matched__gensym9 = true;
        effects.push(leaf);
      }
    }
    if (!matched__gensym9) {
      throw new lyknIntrinsicError0("match: no matching pattern");
    }
  }
  {
    const target__gensym10 = input;
    let matched__gensym11 = false;
    let patternField__gensym2;
    let patternField__gensym3;
    if (!matched__gensym11 && target__gensym10 != null && target__gensym10["tag"] === "CDCScopeCase" && (patternField__gensym2 = target__gensym10["value"], true) && patternField__gensym2 != null && patternField__gensym2["tag"] === "CDCScopeCase" && (patternField__gensym3 = patternField__gensym2["value"], true)) {
      const leaf = patternField__gensym3;
      {
        matched__gensym11 = true;
        return leaf;
      }
    }
    if (!matched__gensym11) {
      throw new lyknIntrinsicError0("match: no matching pattern");
    }
  }
}
console.log(JSON.stringify([select(outer), (() => {
  const t__gensym12 = outer;
  let patternField__gensym4;
  let patternField__gensym5;
  if (t__gensym12 !== null && t__gensym12["tag"] === "CDCScopeCase" && (patternField__gensym4 = t__gensym12["value"], true) && patternField__gensym4 !== null && patternField__gensym4["tag"] === "CDCScopeCase" && (patternField__gensym5 = patternField__gensym4["value"], true)) {
    const leaf = patternField__gensym5;
    return leaf;
  } else {
    return 0;
  }
})(), (() => {
  const t__gensym13 = outer;
  let patternField__gensym6;
  let patternField__gensym7;
  if (t__gensym13 !== null && t__gensym13["tag"] === "CDCScopeCase" && (patternField__gensym6 = t__gensym13["value"], true) && patternField__gensym6 !== null && patternField__gensym6["tag"] === "CDCScopeCase" && (patternField__gensym7 = patternField__gensym6["value"], true)) {
    const leaf = patternField__gensym7;
    return leaf;
  }
})(), effects]));
