const lyknIntrinsicError0 = Error;
console.log((() => {
  const target__gensym7 = {
    tag: "CDCExpr",
    decoy: "cold",
    value: "named"
  };
  let patternField__gensym0;
  if (target__gensym7 !== null && target__gensym7["tag"] === "CDCExpr" && (patternField__gensym0 = Object.values(target__gensym7)[1], true)) {
    const picked = patternField__gensym0;
    return picked;
  }
  throw new lyknIntrinsicError0("match: no matching pattern");
})());
