const lyknIntrinsicTypeError0 = TypeError;
const lyknIntrinsicError0 = Error;
function CDCReentry(outer) {
  if (typeof outer !== "string") {
    throw new lyknIntrinsicTypeError0("CDCReentry: field 'outer' expected string, got " + typeof outer);
  }
  return {
    tag: "CDCReentry",
    outer: outer
  };
}
0;
console.log((() => {
  const target__gensym4 = {
    tag: "CDCReentry",
    outer: "outer marker",
    inner: "inner marker"
  };
  let patternField__gensym0;
  if (target__gensym4 !== null && target__gensym4["tag"] === "CDCReentry" && (patternField__gensym0 = target__gensym4["outer"], true)) {
    const picked = patternField__gensym0;
    return picked;
  }
  throw new lyknIntrinsicError0("match: no matching pattern");
})());
