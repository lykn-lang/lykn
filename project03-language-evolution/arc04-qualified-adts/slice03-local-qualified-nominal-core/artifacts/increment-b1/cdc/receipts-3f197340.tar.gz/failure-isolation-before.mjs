const lyknIntrinsicError0 = Error;
console.log((() => {
  const target__gensym2 = {
    tag: "CDCLate",
    decoy: "cold",
    value: "named"
  };
  let patternField__gensym0;
  if (target__gensym2 !== null && target__gensym2["tag"] === "CDCLate" && (patternField__gensym0 = Object.values(target__gensym2)[1], true)) {
    const picked = patternField__gensym0;
    return picked;
  }
  throw new lyknIntrinsicError0("match: no matching pattern");
})());
