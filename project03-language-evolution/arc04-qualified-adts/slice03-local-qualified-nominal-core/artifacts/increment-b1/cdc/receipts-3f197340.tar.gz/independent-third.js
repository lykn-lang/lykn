const lyknIntrinsicTypeError0 = TypeError;
import {lykn, compile, expandExpr, read} from "/Users/oubiwann/lab/lykn/lang/.worktrees/contract-predicate-lowering/packages/lang/mod.js";
import {macroEnv, sym, array as astArray} from "/Users/oubiwann/lab/lykn/lang/.worktrees/contract-predicate-lowering/packages/lang/expander-core.js";
import {emitSurfaceForm, emitTypeMacro} from "/Users/oubiwann/lab/lykn/lang/.worktrees/contract-predicate-lowering/packages/lang/classifier.js";
import {compilePattern} from "/Users/oubiwann/lab/lykn/lang/.worktrees/contract-predicate-lowering/packages/lang/surface-helpers.js";
import {createSurfaceTypeContext} from "/Users/oubiwann/lab/lykn/lang/.worktrees/contract-predicate-lowering/packages/lang/surface-type-context.js";
const home = "/private/tmp/lykn-s03-b1-cdc-3f197340";
const results = [];
function runOutput(generated, name) {
  if (typeof generated !== "string") {
    throw new lyknIntrinsicTypeError0("runOutput: arg 'generated' expected string, got " + typeof generated);
  }
  if (typeof name !== "string") {
    throw new lyknIntrinsicTypeError0("runOutput: arg 'name' expected string, got " + typeof name);
  }
  const path = home + "/" + name + ".mjs";
  Deno.writeTextFileSync(path, generated);
  const command = new Deno.Command(Deno.execPath(), { args: ["run", "--no-config", "--cached-only", "--no-prompt", path], cwd: home, stdout: "piped", stderr: "piped" });
  const result = command.outputSync();
  Deno.writeFileSync(home + "/" + name + ".stdout", result.stdout);
  Deno.writeFileSync(home + "/" + name + ".stderr", result.stderr);
  const decoder = new TextDecoder();
  const stdout = decoder.decode(result.stdout);
  const stderr = decoder.decode(result.stderr);
  if (!(result.success && stderr === "")) {
    throw new Error(name + " failed: " + stderr);
  }
  const result__gensym0 = stdout;
  if (typeof result__gensym0 !== "string") {
    throw new lyknIntrinsicTypeError0("runOutput: return value expected string, got " + typeof result__gensym0);
  }
  return result__gensym0;
}
function sameOutput(first, second, name) {
  if (typeof first !== "string") {
    throw new lyknIntrinsicTypeError0("sameOutput: arg 'first' expected string, got " + typeof first);
  }
  if (typeof second !== "string") {
    throw new lyknIntrinsicTypeError0("sameOutput: arg 'second' expected string, got " + typeof second);
  }
  if (typeof name !== "string") {
    throw new lyknIntrinsicTypeError0("sameOutput: arg 'name' expected string, got " + typeof name);
  }
  const before = runOutput(first, name + "-before");
  const after = runOutput(second, name + "-after");
  if (!(before === after)) {
    throw new Error(name + " leaked " + before + " -> " + after);
  }
  return results.push({ name: name, before: before, after: after });
}
const plainSource = "(console:log (match (obj :tag \"CDCState\" :decoy \"cold\" :value \"named\") ((CDCState picked) picked)))";
const before = lykn(plainSource);
lykn("(type CDCEnvelope (CDCState :string value))");
sameOutput(before, lykn(plainSource), "success-isolation");
const failureSource = "(console:log (match (obj :tag \"CDCLate\" :decoy \"cold\" :value \"named\") ((CDCLate picked) picked)))";
const failureBefore = lykn(failureSource);
const failed = { value: false };
try {
  lykn("(type CDCFailure (CDCLate :string value)) (not 1 2)");
} catch (error) {
  (() => {
    if (!error.message.includes("not requires exactly 1 argument")) {
      throw error;
    } else {
      return null;
    }
  })();
  failed.value = true;
}
if (!failed.value) {
  throw new Error("late error did not execute");
}
sameOutput(failureBefore, lykn(failureSource), "failure-isolation");
for (const variant of ["success", "failure"]) {
  const macroName = "cdc-b1-reenter";
  const hadPrevious = macroEnv.has(macroName);
  const previous = macroEnv.get(macroName);
  const innerFailed = { value: false };
  macroEnv.set(macroName, () => {
    if (variant === "success") {
      lykn("(type CDCInner (CDCReentry :string inner))");
    } else {
      try {
        lykn("(type CDCInner (CDCReentry :string inner)) (not 1 2)");
      } catch (error) {
        (() => {
          if (!error.message.includes("not requires exactly 1 argument")) {
            throw error;
          } else {
            return null;
          }
        })();
        innerFailed.value = true;
      }
    }
    return { type: "number", value: 0 };
  });
  try {
    const generated = lykn("(type CDCOuter (CDCReentry :string outer)) (cdc-b1-reenter) (console:log (match (obj :tag \"CDCReentry\" :outer \"outer marker\" :inner \"inner marker\") ((CDCReentry picked) picked)))");
    const output = runOutput(generated, "reentrant-" + variant);
    if (!(output === "outer marker\n")) {
      throw new Error("reentry " + variant + ": " + output);
    } else {
      null;
    }
    if (variant === "failure" && !innerFailed.value) {
      throw new Error("inner failure did not execute");
    } else {
      null;
    }
    results.push({ name: "reentrant-" + variant, stdout: output, innerFailed: innerFailed.value });
  } finally {
    hadPrevious ? macroEnv.set(macroName, previous) : macroEnv.delete(macroName);
  }
}
const exprSource = "(console:log (match (obj :tag \"CDCExpr\" :decoy \"cold\" :value \"named\") ((CDCExpr picked) picked)))";
const exprBefore = compile([expandExpr(read(exprSource)[0])]);
expandExpr(read("(type CDCExprEnvelope (CDCExpr :string value))")[0]);
const exprAfter = compile([expandExpr(read(exprSource)[0])]);
sameOutput(exprBefore, exprAfter, "expr-to-expr-isolation");
const nested = lykn("(type CDCScope (CDCScopeCase :any value)) (bind inner (obj :tag \"CDCScopeCase\" :decoy 9 :value 42)) (bind outer (obj :tag \"CDCScopeCase\" :decoy 7 :value inner)) (bind effects (array)) (func select :args (:any input) :body (match input ((CDCScopeCase (CDCScopeCase leaf)) (effects:push leaf))) (match input ((CDCScopeCase (CDCScopeCase leaf)) leaf))) (console:log (JSON:stringify (array (select outer) (if-let ((CDCScopeCase (CDCScopeCase leaf)) outer) leaf 0) (when-let ((CDCScopeCase (CDCScopeCase leaf)) outer) leaf) effects)))");
const nestedOutput = runOutput(nested, "nested-scope-patterns");
if (!(nestedOutput === "[42,42,42,[42]]\n")) {
  throw new Error("nested: " + nestedOutput);
}
results.push({ name: "nested-value-statement-if-let-when-let", stdout: nestedOutput });
const notNode = emitSurfaceForm({ type: "Not", operand: sym("x") }, { sym: sym, array: astArray });
if (!(compile([notNode]) === "!x;\n")) {
  throw new Error("context-free Not changed");
}
compilePattern(sym("_"), sym("target"));
const missingContext = { value: false };
try {
  compilePattern(read("(CDCMissing value)")[0], sym("target"));
} catch (error) {
  (() => {
    if (!(error instanceof TypeError && error.message.includes("typeContext is required"))) {
      throw error;
    } else {
      return null;
    }
  })();
  missingContext.value = true;
}
if (!missingContext.value) {
  throw new Error("missing metadata context was accepted");
}
const firstContext = createSurfaceTypeContext();
const secondContext = createSurfaceTypeContext();
const firstSeed = firstContext.constructors["Some"];
firstSeed.push("mutated");
if (!(secondContext.constructors["Some"]["length"] === 1)) {
  throw new Error("seed arrays shared");
}
const surfaceModule = await import("file:///Users/oubiwann/lab/lykn/lang/.worktrees/contract-predicate-lowering/packages/lang/surface.js");
if (Object.hasOwn(surfaceModule, "resetTypeRegistry")) {
  throw new Error("removed reset export still present");
}
results.push({ name: "helper-and-export-boundaries", not: true, literal: true, missingContextRejected: missingContext.value, freshSeedArrays: true, removedResetExport: true });
Deno.writeTextFileSync(home + "/independent-results.json", JSON.stringify(results, null, 2));
console.log(JSON.stringify(results, null, 2));
