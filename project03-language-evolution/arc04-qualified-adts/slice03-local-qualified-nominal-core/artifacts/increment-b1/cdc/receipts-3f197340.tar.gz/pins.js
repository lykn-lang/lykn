const lyknIntrinsicArrayIsArray0 = Array.isArray;
const lyknIntrinsicTypeError0 = TypeError;
const home = "/private/tmp/lykn-s03-b1-cdc-3f197340";
const source = "/Users/oubiwann/lab/lykn/lang/.worktrees/contract-predicate-lowering";
const commands = [["git", "status", "--short", "--branch"], ["git", "rev-parse", "HEAD", "HEAD^{tree}"], ["git", "show", "-s", "--format=%B", "HEAD"], ["git", "diff", "--name-only", "5caf3d87..HEAD"], ["git", "diff", "5caf3d87..HEAD"], ["rustc", "--version"], ["cargo", "--version"], ["deno", "--version"], ["shasum", "-a", "256", "target/release/lykn", "bin/lykn", "/private/tmp/lykn-s03-b1-cdc-3f197340/cold-cli/standalone/lykn"]];
const observations = commands.map(argv => {
  if (!lyknIntrinsicArrayIsArray0(argv)) {
    throw new lyknIntrinsicTypeError0("anonymous: arg 'argv' expected array, got " + typeof argv);
  }
  const command = new Deno.Command(argv[0], { args: argv.slice(1), cwd: source, stdout: "piped", stderr: "piped" });
  const result = command.outputSync();
  const decoder = new TextDecoder();
  return { argv: argv, cwd: source, code: result.code, stdout: decoder.decode(result.stdout), stderr: decoder.decode(result.stderr) };
});
Deno.writeTextFileSync(home + "/pins.json", JSON.stringify(observations, null, 2));
console.log(JSON.stringify(observations, null, 2));
