const lyknIntrinsicArrayIsArray0 = Array.isArray;
const lyknIntrinsicTypeError0 = TypeError;
function outer(Array) {
  function choose(...args) {
    if (args.length === 1 && Array.isArray(args[0])) {
      const value = args[0];
      if (!lyknIntrinsicArrayIsArray0(value)) {
        throw new lyknIntrinsicTypeError0("choose: arg 'value' expected array, got " + typeof value);
      }
      return "array";
    }
    if (args.length === 1 && typeof args[0] === "string") {
      const value = args[0];
      if (typeof value !== "string") {
        throw new lyknIntrinsicTypeError0("choose: arg 'value' expected string, got " + typeof value);
      }
      return "string";
    }
    throw new lyknIntrinsicTypeError0("choose: no matching clause for arguments");
  }
  return choose([1]);
}
try {
  console.log(JSON.stringify(outer(0)));
} catch (problem) {
  console.log(JSON.stringify([problem.name, problem.message]));
}
