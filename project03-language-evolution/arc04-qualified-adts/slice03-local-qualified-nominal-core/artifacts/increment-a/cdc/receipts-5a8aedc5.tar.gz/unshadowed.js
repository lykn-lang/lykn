"use strict";
const lyknIntrinsicSymbol0 = Symbol;
const lyknIntrinsicSymbolFor0 = Symbol.for;
const lyknIntrinsicObjectFreeze0 = Object.freeze;
const lyknIntrinsicObjectDefineProperties0 = Object.defineProperties;
const lyknIntrinsicNumberIsNaN0 = Number.isNaN;
const lyknIntrinsicArrayIsArray0 = Array.isArray;
const lyknIntrinsicPromise0 = Promise;
const lyknIntrinsicTypeError0 = TypeError;
const lyknIntrinsicError0 = Error;
const observed = [lyknIntrinsicSymbol0("local"), lyknIntrinsicSymbolFor0("lykn.s03.a.review"), lyknIntrinsicObjectFreeze0({
  field: 7
}), lyknIntrinsicObjectDefineProperties0({}, {
  field: {
    value: 8,
    enumerable: true
  }
}), lyknIntrinsicNumberIsNaN0(NaN), lyknIntrinsicArrayIsArray0([1]), new lyknIntrinsicPromise0(resolve => resolve(9)), new lyknIntrinsicTypeError0("typed"), new lyknIntrinsicError0("error")];
export {observed};
