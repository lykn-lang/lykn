const lyknIntrinsicTypeError0 = TypeError;
function outer(Array) {
  function choose(...args) {
    if (args.length === 1 && Array.isArray(args[0])) {
      const value = args[0];
      return "array";
    }
    if (args.length === 1 && typeof args[0] === "string") {
      const value = args[0];
      return "string";
    }
    throw new lyknIntrinsicTypeError0("choose: no matching clause for arguments");
  }
  return choose([1]);
}
try {
  console.log(JSON.stringify(outer(0)));
} catch (problem) {
  console.log(JSON.stringify([problem.name, problem.message]));
}
