const home = "/private/tmp/lykn-s03-a-cdc-5a8aedc5";
const source = "/Users/oubiwann/lab/lykn/lang/.worktrees/contract-predicate-lowering";
const scenarios = [{ name: "dispatch-stripped", input: "dispatch.lykn", strip: true }, { name: "dispatch-parameter", input: "dispatch-parameter.lykn", strip: false }, { name: "dispatch-parameter-stripped", input: "dispatch-parameter.lykn", strip: true }];
for (const scenario of scenarios) {
  const argv = ["run", "--no-config", "--cached-only", "-A", home + "/run.js", home + "/receipts/" + scenario.name + "-compile", source, source + "/bin/lykn", "compile", home + "/" + scenario.input, "-o", home + "/" + scenario.name + ".js"];
  if (scenario.strip) {
    argv.push("--strip-assertions");
  }
  const compileCommand = new Deno.Command("deno", { args: argv, stdout: "inherit", stderr: "inherit" });
  const compiled = compileCommand.outputSync();
  if (!compiled.success) {
    throw new Error("review probe compile failed");
  }
  const runtimeCommand = new Deno.Command("deno", { args: ["run", "--no-config", "--cached-only", "-A", home + "/run.js", home + "/receipts/" + scenario.name + "-runtime", home, "deno", "run", "--no-config", "--cached-only", "--no-npm", "--no-remote", "--deny-net", "--no-prompt", scenario.name + ".js"], stdout: "inherit", stderr: "inherit" });
  const ran = runtimeCommand.outputSync();
  if (!ran.success) {
    throw new Error("review probe runtime process failed");
  }
}
