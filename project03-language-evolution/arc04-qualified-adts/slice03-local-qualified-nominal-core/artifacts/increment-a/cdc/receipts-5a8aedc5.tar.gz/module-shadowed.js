"use strict";
import {symbol as lyknIntrinsicSymbol0, symbolFor as lyknIntrinsicSymbolFor0, objectFreeze as lyknIntrinsicObjectFreeze0, objectDefineProperties as lyknIntrinsicObjectDefineProperties0, numberIsNaN as lyknIntrinsicNumberIsNaN0, arrayIsArray as lyknIntrinsicArrayIsArray0, promise as lyknIntrinsicPromise0, typeError as lyknIntrinsicTypeError0, error as lyknIntrinsicError0} from "data:text/javascript,export%20const%20symbol%3DSymbol%3Bexport%20const%20symbolFor%3DSymbol.for%3Bexport%20const%20objectFreeze%3DObject.freeze%3Bexport%20const%20objectDefineProperties%3DObject.defineProperties%3Bexport%20const%20numberIsNaN%3DNumber.isNaN%3Bexport%20const%20arrayIsArray%3DArray.isArray%3Bexport%20const%20promise%3DPromise%3Bexport%20const%20typeError%3DTypeError%3Bexport%20const%20error%3DError%3B";
const Symbol = 0;
const Object = 0;
const Number = 0;
const Array = 0;
const Promise = 0;
const TypeError = 0;
const Error = 0;
const observed = [lyknIntrinsicSymbol0("local"), lyknIntrinsicSymbolFor0("lykn.s03.a.review"), lyknIntrinsicObjectFreeze0({
  field: 7
}), lyknIntrinsicObjectDefineProperties0({}, {
  field: {
    value: 8,
    enumerable: true
  }
}), lyknIntrinsicNumberIsNaN0(NaN), lyknIntrinsicArrayIsArray0([1]), new lyknIntrinsicPromise0(resolve => resolve(9)), new lyknIntrinsicTypeError0("typed"), new lyknIntrinsicError0("error")];
export {observed};
