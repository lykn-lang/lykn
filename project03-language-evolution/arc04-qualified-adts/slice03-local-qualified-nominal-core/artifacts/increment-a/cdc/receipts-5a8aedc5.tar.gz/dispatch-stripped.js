const lyknIntrinsicTypeError0 = TypeError;
const Array = 0;
function choose(...args) {
  if (args.length === 1 && Array.isArray(args[0])) {
    const value = args[0];
    return "array";
  }
  if (args.length === 1 && typeof args[0] === "string") {
    const value = args[0];
    return "string";
  }
  throw new lyknIntrinsicTypeError0("choose: no matching clause for arguments");
}
try {
  console.log(JSON.stringify(choose([1])));
} catch (problem) {
  console.log(JSON.stringify([problem.name, problem.message]));
}
