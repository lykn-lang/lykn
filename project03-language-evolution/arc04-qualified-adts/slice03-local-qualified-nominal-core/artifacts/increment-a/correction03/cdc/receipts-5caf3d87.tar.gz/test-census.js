const lyknIntrinsicTypeError0 = TypeError;
const source = Deno.readTextFileSync("/Users/oubiwann/lab/lykn/lang/.worktrees/contract-predicate-lowering/crates/lykn-lang/src/emitter/forms.rs");
const sections = source.split("    #[test]");
const tests = sections.slice(1);
const rows = tests.map(body => {
  if (typeof body !== "string") {
    throw new lyknIntrinsicTypeError0("anonymous: arg 'body' expected string, got " + typeof body);
  }
  const match = body.match(/fn ([A-Za-z0-9_]+)/);
  return { name: match[1], rawLocalAlias: body.includes("use super::emit_form_raw_checked as emit_form;"), emitFormCall: body.includes("emit_form(") };
});
const raw = rows.filter(row => {
  if (typeof row !== "object" || row === null) {
    throw new lyknIntrinsicTypeError0("anonymous: arg 'row' expected object, got " + typeof row);
  }
  return row.rawLocalAlias;
});
const publicCalls = rows.filter(row => {
  if (typeof row !== "object" || row === null) {
    throw new lyknIntrinsicTypeError0("anonymous: arg 'row' expected object, got " + typeof row);
  }
  return !row.rawLocalAlias && row.emitFormCall;
});
const other = rows.filter(row => {
  if (typeof row !== "object" || row === null) {
    throw new lyknIntrinsicTypeError0("anonymous: arg 'row' expected object, got " + typeof row);
  }
  return !row.rawLocalAlias && !row.emitFormCall;
});
const result = { total: rows.length, rawLocalAliasCount: raw.length, remainingCount: rows.length - raw.length, publicEmitFormCallCount: publicCalls.length, otherHelperTestCount: other.length, rawTests: raw, otherTests: other };
Deno.writeTextFileSync("/private/tmp/lykn-s03-a-cdc-5caf3d87/test-census.json", JSON.stringify(result, null, 2));
console.log(JSON.stringify(result, null, 2));
