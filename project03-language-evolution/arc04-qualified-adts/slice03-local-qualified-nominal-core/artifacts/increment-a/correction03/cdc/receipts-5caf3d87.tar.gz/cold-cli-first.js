const lyknIntrinsicNumberIsNaN0 = Number.isNaN;
const lyknIntrinsicTypeError0 = TypeError;
const home = "/private/tmp/lykn-s03-a-cdc-5caf3d87";
const source = "/Users/oubiwann/lab/lykn/lang/.worktrees/contract-predicate-lowering";
const cold = home + "/cold-cli";
const standalone = cold + "/standalone";
const cache = cold + "/xdg";
const package = cache + "/lykn/embedded/0.6.0-compiler-split/packages/lang";
Deno.mkdirSync(standalone, { recursive: true });
Deno.mkdirSync(cache, { recursive: true });
if (Array.from(Deno.readDirSync(cache))["length"]) {
  throw new Error("owned cold cache was not empty");
}
if (Array.from(Deno.readDirSync(standalone))["length"]) {
  throw new Error("standalone directory was not empty");
}
Deno.copyFileSync(source + "/bin/lykn", standalone + "/lykn");
const trigger = "(macro delivery-twice (x) `(+ ,x ,x))\n(console:log (JSON:stringify (delivery-twice 21)))\n";
const fixture = Deno.readTextFileSync(source + "/test/fixtures/semantic-roles/host-reference-shadowing.lykn");
Deno.writeTextFileSync(standalone + "/input.lykn", trigger + fixture);
const argv = ["compile", standalone + "/input.lykn", "-o", standalone + "/output.mjs"];
const compileCommand = new Deno.Command(standalone + "/lykn", { args: argv, cwd: standalone, env: { XDG_CACHE_HOME: cache }, stdout: "piped", stderr: "piped" });
const compiled = compileCommand.outputSync();
Deno.writeFileSync(cold + "/compile.stdout", compiled.stdout);
Deno.writeFileSync(cold + "/compile.stderr", compiled.stderr);
if (!compiled.success) {
  throw new Error("standalone compile failed");
}
const names = ["binding.js", "classifier.js", "compiler.js", "compiler-private-atoms.js", "expander-core.js", "protected-host.js", "surface-helpers.js", "deno.json", "deno.lock"];
const comparisons = names.map(name => {
  if (typeof name !== "string") {
    throw new lyknIntrinsicTypeError0("anonymous: arg 'name' expected string, got " + typeof name);
  }
  const embedded = Deno.readFileSync(source + "/crates/lykn-lang/embedded/packages/lang/" + name);
  const materialized = Deno.readFileSync(package + "/" + name);
  const equal = embedded.length === materialized.length && embedded.every((byte, index) => {
    if (typeof byte !== "number" || lyknIntrinsicNumberIsNaN0(byte)) {
      throw new lyknIntrinsicTypeError0("anonymous: arg 'byte' expected number, got " + typeof byte);
    }
    if (typeof index !== "number" || lyknIntrinsicNumberIsNaN0(index)) {
      throw new lyknIntrinsicTypeError0("anonymous: arg 'index' expected number, got " + typeof index);
    }
    return byte === materialized[index];
  });
  if (!equal) {
    throw new Error("materialized byte drift: " + name);
  }
  return { name: name, bytes: embedded.length, equal: equal };
});
const runtimeArgs = ["run", "--no-config", "--cached-only", "--no-npm", "--no-remote", "--deny-net", "--no-prompt", standalone + "/output.mjs"];
const runtimeCommand = new Deno.Command(Deno.execPath(), { args: runtimeArgs, cwd: standalone, stdout: "piped", stderr: "piped" });
const runtime = runtimeCommand.outputSync();
Deno.writeFileSync(cold + "/runtime.stdout", runtime.stdout);
Deno.writeFileSync(cold + "/runtime.stderr", runtime.stderr);
const decoder = new TextDecoder();
const stdout = decoder.decode(runtime.stdout);
const stderr = decoder.decode(runtime.stderr);
const expected = "42\n[[\"TypeError\",\"checkNumber: arg 'value' expected number, got string\"],[\"TypeError\",\"checkArray: arg 'value' expected array, got number\"],[\"Error\",\"match: no matching pattern\"]]\n";
if (!((runtime.success && stdout === expected) && stderr === "")) {
  throw new Error("standalone runtime mismatch: " + stdout + stderr);
}
const result = { sourcePin: "5caf3d871a80a711c08dbda0db8c5f5446dffb56", copiedFrom: source + "/bin/lykn", copiedCli: standalone + "/lykn", compileArgv: argv, runtimeArgv: runtimeArgs, cwd: standalone, XDG_CACHE_HOME: cache, coldEmptyBefore: true, noCanonicalPackageFallback: true, compileCode: compiled.code, runtimeCode: runtime.code, runtimeStdout: stdout, runtimeStderr: stderr, comparisons: comparisons };
Deno.writeTextFileSync(cold + "/result.json", JSON.stringify(result, null, 2));
console.log(JSON.stringify(result, null, 2));
