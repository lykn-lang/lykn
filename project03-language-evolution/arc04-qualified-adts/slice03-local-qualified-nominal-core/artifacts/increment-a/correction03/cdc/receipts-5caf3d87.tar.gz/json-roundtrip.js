import {compile} from "/Users/oubiwann/lab/lykn/lang/.worktrees/contract-predicate-lowering/packages/lang/compiler.js";
const home = "/private/tmp/lykn-s03-a-cdc-5caf3d87";
const source = "/Users/oubiwann/lab/lykn/lang/.worktrees/contract-predicate-lowering";
const argv = ["compile", source + "/test/fixtures/semantic-roles/host-reference-shadowing.lykn", "--kernel-json"];
const command = new Deno.Command(source + "/bin/lykn", { args: argv, cwd: source, stdout: "piped", stderr: "piped" });
const result = command.outputSync();
Deno.writeFileSync(home + "/kernel-json.stdout", result.stdout);
Deno.writeFileSync(home + "/kernel-json.stderr", result.stderr);
if (!result.success) {
  throw new Error("native complete-unit JSON failed");
}
const decoder = new TextDecoder();
const forms = JSON.parse(decoder.decode(result.stdout));
const generated = compile(forms);
const path = home + "/kernel-json-public.mjs";
Deno.writeTextFileSync(path, generated);
const runtimeCommand = new Deno.Command(Deno.execPath(), { args: ["run", "--no-config", "--cached-only", "--no-npm", "--no-remote", "--deny-net", "--no-prompt", path], cwd: home, stdout: "piped", stderr: "piped" });
const runtime = runtimeCommand.outputSync();
Deno.writeFileSync(home + "/kernel-json-runtime.stdout", runtime.stdout);
Deno.writeFileSync(home + "/kernel-json-runtime.stderr", runtime.stderr);
const stdout = decoder.decode(runtime.stdout);
const stderr = decoder.decode(runtime.stderr);
const expected = "[[\"TypeError\",\"checkNumber: arg 'value' expected number, got string\"],[\"TypeError\",\"checkArray: arg 'value' expected array, got number\"],[\"Error\",\"match: no matching pattern\"]]\n";
if (!((runtime.success && stdout === expected) && stderr === "")) {
  throw new Error("JSON/public runtime mismatch: " + stdout + stderr);
}
console.log(JSON.stringify({ argv: argv, nativeCode: result.code, forms: forms.length, publicRuntimeCode: runtime.code, publicRuntimeStdout: stdout, publicRuntimeStderr: stderr }, null, 2));
