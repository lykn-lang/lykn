const bind = (first, second) => typeof second;
console.log({ package: "property-ok" }["package"]);
console.log(bind(1, eval));
