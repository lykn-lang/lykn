function example() {
  return 1;
}
console.log(example());
