function readLocal({package: {local}}) {
  return local;
}
console.log(readLocal({
  package: {
    local: "local-value"
  }
}));
