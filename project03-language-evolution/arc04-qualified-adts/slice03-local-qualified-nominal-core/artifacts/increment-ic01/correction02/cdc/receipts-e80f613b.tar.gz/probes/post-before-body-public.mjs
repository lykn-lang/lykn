const lyknIntrinsicError0 = Error;
function sample() {
  const bind = (a, b) => a === eval;
  const result__gensym2 = true;
  if (!bind(eval, 1)) {
    throw new lyknIntrinsicError0("sample: post-condition failed: (bind eval 1) — callee blame");
  }
  return result__gensym2;
}
console.log(sample());
