const lyknIntrinsicArrayIsArray0 = Array.isArray;
const lyknIntrinsicTypeError0 = TypeError;
const home = "/private/tmp/lykn-s03-ic01-cdc-e80f613b";
const standalone = home + "/cold-cli/standalone";
const executable = standalone + "/lykn";
const cache = home + "/cold-cli/xdg";
const rows = [];
const decoder = new TextDecoder();
function invoke(label, binary, argv) {
  if (typeof label !== "string") {
    throw new lyknIntrinsicTypeError0("invoke: arg 'label' expected string, got " + typeof label);
  }
  if (typeof binary !== "string") {
    throw new lyknIntrinsicTypeError0("invoke: arg 'binary' expected string, got " + typeof binary);
  }
  if (!lyknIntrinsicArrayIsArray0(argv)) {
    throw new lyknIntrinsicTypeError0("invoke: arg 'argv' expected array, got " + typeof argv);
  }
  const child = new Deno.Command(binary, { args: argv, cwd: standalone, env: { XDG_CACHE_HOME: cache }, stdout: "piped", stderr: "piped" });
  const result = child.outputSync();
  Deno.writeFileSync(home + "/cold-cli/" + label + ".stdout", result.stdout);
  Deno.writeFileSync(home + "/cold-cli/" + label + ".stderr", result.stderr);
  const row = { label: label, argv: argv, code: result.code, stdout: decoder.decode(result.stdout), stderr: decoder.decode(result.stderr) };
  rows.push(row);
  return row;
}
const negatives = [["package", "(bind package 1)", "package"], ["normalized-if", "(bind if! 1)", "if"], ["loop-alias", "(for-of (object (alias :value package)) (array (obj :value 1)) 1)", "package"], ["macro-parameter", "(macro restricted (params) `(fn ,params 0)) (bind example (restricted (:any package)))", "package"]];
for (const entry of negatives) {
  const name = entry[0];
  const input = standalone + "/negative-" + name + ".lykn";
  Deno.writeTextFileSync(input, entry[1]);
  for (const mode of ["checked", "stripped", "check"]) {
    const argv = mode === "check" ? ["check", input] : ["compile", input, "-o", standalone + "/negative-" + name + "-" + mode + ".mjs"];
    if (mode === "stripped") {
      argv.push("--strip-assertions");
    }
    const result = invoke(name + "-" + mode, executable, argv);
    if (!(result.code === 1 && result.stderr.includes(entry[2]))) {
      throw new Error("negative failed: " + name + " " + mode);
    }
  }
}
const safe = standalone + "/legal.lykn";
Deno.writeTextFileSync(safe, "(bind bind (fn (:any first :any second) (js:typeof second)))\n(console:log (get (obj :package \"property-ok\") \"package\"))\n(console:log (bind 1 eval))\n");
for (const mode of ["checked", "stripped"]) {
  const output = standalone + "/legal-" + mode + ".mjs";
  const argv = ["compile", safe, "-o", output];
  if (mode === "stripped") {
    argv.push("--strip-assertions");
  }
  const compiled = invoke("legal-" + mode, executable, argv);
  if (!(compiled.code === 0)) {
    throw new Error(compiled.stderr);
  }
  const ran = invoke("legal-" + mode + "-runtime", Deno.execPath(), ["run", "--no-config", "--cached-only", "--no-npm", "--no-remote", "--deny-net", "--no-prompt", output]);
  if (!((ran.code === 0 && ran.stdout === "property-ok\nfunction\n") && ran.stderr === "")) {
    throw new Error("positive module failed: " + ran.stderr);
  }
}
const checked = invoke("legal-check", executable, ["check", safe]);
if (!(checked.code === 0)) {
  throw new Error(checked.stderr);
}
Deno.writeTextFileSync(home + "/cold-cli/controls.json", JSON.stringify(rows, null, 2));
console.log(JSON.stringify(rows, null, 2));
