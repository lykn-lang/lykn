const home = "/private/tmp/lykn-s03-ic01-cdc-e80f613b";
const rows = JSON.parse(Deno.readTextFileSync(home + "/census-results.json"));
const summary = rows.map(row => {
  const errors = row.stderr ? row.stderr : "";
  const lines = errors.split("\n");
  return { label: row.label, code: row.code, accepted: row.accepted, stdout: row.stdout, error: lines[0], message: row.message };
});
Deno.writeTextFileSync(home + "/replay-summary.json", JSON.stringify(summary, null, 2));
console.log(JSON.stringify(summary, null, 2));
