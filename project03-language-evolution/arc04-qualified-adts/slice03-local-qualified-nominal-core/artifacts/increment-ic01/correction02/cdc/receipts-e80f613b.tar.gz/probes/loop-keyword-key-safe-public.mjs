for (const {value: safe} of [{
  value: 1
}]) {
  console.log(safe);
}
