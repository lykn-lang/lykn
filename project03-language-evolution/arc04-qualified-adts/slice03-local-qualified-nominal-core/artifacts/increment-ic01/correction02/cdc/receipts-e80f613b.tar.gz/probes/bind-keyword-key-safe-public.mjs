const {value: safe} = {
  value: 1
};
console.log(safe);
