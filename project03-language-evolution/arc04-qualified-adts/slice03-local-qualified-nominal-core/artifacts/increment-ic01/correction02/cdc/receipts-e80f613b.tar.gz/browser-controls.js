import {compileLykn} from "/Users/oubiwann/lab/lykn/lang/.worktrees/contract-predicate-lowering/packages/browser/compiler.js";
const home = "/private/tmp/lykn-s03-ic01-cdc-e80f613b";
const worktree = "/Users/oubiwann/lab/lykn/lang/.worktrees/contract-predicate-lowering";
const cases = [];
for (const source of ["(bind package 1)", "(bind if! 1)", "(for-of (object (alias :value package)) (array (obj :value 1)) 1)"]) {
  const state = { rejected: false };
  try {
    compileLykn(source);
  } catch (error) {
    state.rejected = true;
    cases.push({ source: source, rejected: true, message: error.message });
  }
  if (!state.rejected) {
    throw new Error("browser reserved binder accepted");
  }
}
const fixture = Deno.readTextFileSync(worktree + "/test/fixtures/semantic-roles/host-reference-shadowing.lykn");
const moduleText = compileLykn(fixture);
if (!moduleText.includes("data:text/javascript")) {
  throw new Error("browser host-root collisions did not select ESM fallback");
}
const output = home + "/browser-output.mjs";
Deno.writeTextFileSync(output, moduleText);
const child = new Deno.Command(Deno.execPath(), { args: ["run", "--no-config", "--cached-only", "--no-npm", "--no-remote", "--deny-net", "--no-prompt", output], cwd: worktree, stdout: "piped", stderr: "piped" });
const result = child.outputSync();
Deno.writeFileSync(home + "/browser-runtime.stdout", result.stdout);
Deno.writeFileSync(home + "/browser-runtime.stderr", result.stderr);
const decoder = new TextDecoder();
const stdout = decoder.decode(result.stdout);
const stderr = decoder.decode(result.stderr);
const expected = "[[\"TypeError\",\"checkNumber: arg 'value' expected number, got string\"],[\"TypeError\",\"checkArray: arg 'value' expected array, got number\"],[\"Error\",\"match: no matching pattern\"]]\n";
if (!((result.success && stdout === expected) && stderr === "")) {
  throw new Error("browser actual ESM mismatch: " + stdout + stderr);
}
const observation = { negatives: cases, fallbackImport: true, code: result.code, stdout: stdout, stderr: stderr };
Deno.writeTextFileSync(home + "/browser-result.json", JSON.stringify(observation, null, 2));
console.log(JSON.stringify(observation, null, 2));
