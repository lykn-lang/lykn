const lyknIntrinsicTypeError0 = TypeError;
import {read} from "/Users/oubiwann/lab/lykn/lang/.worktrees/contract-predicate-lowering/packages/lang/mod.js";
import {walkBindings} from "/Users/oubiwann/lab/lykn/lang/.worktrees/contract-predicate-lowering/packages/lang/binding.js";
import {parseKeywordClauses, FUNC_CLAUSE_KEYS} from "/Users/oubiwann/lab/lykn/lang/.worktrees/contract-predicate-lowering/packages/lang/function-clauses.js";
import {parseKeywordClauses as classifierParser, FUNC_CLAUSE_KEYS as classifierKeys} from "/Users/oubiwann/lab/lykn/lang/.worktrees/contract-predicate-lowering/packages/lang/classifier.js";
const inputs = ["(function example ((default value (do (bind local (fn (:any inner) inner)) local))) (return value))", "(fn ((default :any value (do (bind local (fn (:any inner) inner)) local))) value)", "(=> ((default value (do (bind local (fn (:any inner) inner)) local))) value)", "(class Example () (method ((default value (do (bind local (fn (:any inner) inner)) local))) (return value)))", "(kernel:const (object (default value (bind local (fn (:any inner) inner)))) source)"];
const rows = inputs.map(source => {
  if (typeof source !== "string") {
    throw new lyknIntrinsicTypeError0("anonymous: arg 'source' expected string, got " + typeof source);
  }
  const sites = walkBindings(read(source));
  return { source: source, names: sites.map(site => site.name) };
});
const result = { parserIdentity: parseKeywordClauses === classifierParser, keySetIdentity: FUNC_CLAUSE_KEYS === classifierKeys, rows: rows };
Deno.writeTextFileSync("/private/tmp/lykn-s03-ic01-cdc-b8a1fa17/extra-role-results.json", JSON.stringify(result, null, 2));
console.log(JSON.stringify(result, null, 2));
