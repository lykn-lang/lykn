for (const {"value": package} of [{ value: 1 }]) {
  console.log(1);
}
