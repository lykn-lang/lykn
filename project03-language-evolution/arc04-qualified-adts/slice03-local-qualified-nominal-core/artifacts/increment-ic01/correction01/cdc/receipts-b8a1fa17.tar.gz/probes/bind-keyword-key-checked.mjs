const {"value": package} = { value: 1 };
console.log(1);
