try {
  throw { value: 1 };
} catch ({ alias: "value" }) {
  console.log(safe);
}
