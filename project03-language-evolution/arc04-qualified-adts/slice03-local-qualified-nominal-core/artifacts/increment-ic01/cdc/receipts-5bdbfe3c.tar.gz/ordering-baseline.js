const lyknIntrinsicArrayIsArray0 = Array.isArray;
const lyknIntrinsicTypeError0 = TypeError;
const home = "/private/tmp/lykn-s03-ic01-cdc-5bdbfe3c";
const baselineCli = "/private/tmp/lykn-s03-b1-cdc-3f197340/cold-cli/standalone/lykn";
const baselineModule = await import("file://" + home + "/baseline/packages/lang/mod.js");
const decoder = new TextDecoder();
const rows = [];
function invoke(label, executable, argv) {
  if (typeof label !== "string") {
    throw new lyknIntrinsicTypeError0("invoke: arg 'label' expected string, got " + typeof label);
  }
  if (typeof executable !== "string") {
    throw new lyknIntrinsicTypeError0("invoke: arg 'executable' expected string, got " + typeof executable);
  }
  if (!lyknIntrinsicArrayIsArray0(argv)) {
    throw new lyknIntrinsicTypeError0("invoke: arg 'argv' expected array, got " + typeof argv);
  }
  const command = new Deno.Command(executable, { args: argv, cwd: home, env: { XDG_CACHE_HOME: home + "/baseline-xdg" }, stdout: "piped", stderr: "piped" });
  const result = command.outputSync();
  Deno.writeFileSync(home + "/probes/" + label + ".stdout", result.stdout);
  Deno.writeFileSync(home + "/probes/" + label + ".stderr", result.stderr);
  const observation = { label: label, executable: executable, argv: argv, code: result.code, stdout: decoder.decode(result.stdout), stderr: decoder.decode(result.stderr) };
  rows.push(observation);
  return observation;
}
for (const name of ["post-before-body", "body-before-post"]) {
  const sourcePath = home + "/probes/" + name + ".lykn";
  const output = home + "/probes/" + name + "-baseline-native.mjs";
  const result = invoke(name + "-baseline-native", baselineCli, ["compile", sourcePath, "-o", output]);
  if (result.code === 0) {
    invoke(name + "-baseline-native-runtime", Deno.execPath(), ["run", "--no-config", "--cached-only", "--no-npm", "--no-remote", "--no-prompt", output]);
  }
  invoke(name + "-baseline-check", baselineCli, ["check", sourcePath]);
  try {
    const generated = baselineModule.lykn(Deno.readTextFileSync(sourcePath));
    const publicOutput = home + "/probes/" + name + "-baseline-public.mjs";
    Deno.writeTextFileSync(publicOutput, generated);
    rows.push({ label: name + "-baseline-public", accepted: true });
    invoke(name + "-baseline-public-runtime", Deno.execPath(), ["run", "--no-config", "--cached-only", "--no-npm", "--no-remote", "--no-prompt", publicOutput]);
  } catch (error) {
    rows.push({ label: name + "-baseline-public", accepted: false, message: error.message });
  }
}
Deno.writeTextFileSync(home + "/ordering-baseline-results.json", JSON.stringify(rows, null, 2));
console.log(JSON.stringify(rows, null, 2));
