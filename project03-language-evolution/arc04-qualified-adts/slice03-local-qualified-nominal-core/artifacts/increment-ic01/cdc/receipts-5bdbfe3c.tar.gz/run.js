const lyknIntrinsicTypeError0 = TypeError;
const receipt = Deno.args[0];
const cwd = Deno.args[1];
const executable = Deno.args[2];
const argv = Deno.args.slice(3);
Deno.mkdirSync(receipt, { recursive: true });
const keys = ["PATH", "DENO_DIR", "XDG_CACHE_HOME", "TMPDIR", "npm_config_cache", "LYKN_MACRO_DEPENDENCIES_EVIDENCE_DIR"];
const environment = Object.fromEntries(keys.map(key => {
  if (typeof key !== "string") {
    throw new lyknIntrinsicTypeError0("anonymous: arg 'key' expected string, got " + typeof key);
  }
  return [key, Deno.env.get(key)];
}));
const launch = { executable: executable, argv: argv, cwd: cwd, sourcePin: "5bdbfe3c27c58bdcbf93471d1c469c53ef2eaabe", startedAt: Date.now(), environment: environment };
Deno.writeTextFileSync(receipt + "/launch.json", JSON.stringify(launch, null, 2));
const command = new Deno.Command(executable, { args: argv, cwd: cwd, stdout: "piped", stderr: "piped" });
const result = command.outputSync();
Deno.writeFileSync(receipt + "/stdout.raw", result.stdout);
Deno.writeFileSync(receipt + "/stderr.raw", result.stderr);
Deno.writeTextFileSync(receipt + "/exit-status.json", JSON.stringify({ code: result.code, success: result.success, finishedAt: Date.now() }, null, 2));
console.log(JSON.stringify({ receipt: receipt, code: result.code, stdoutBytes: result.stdout.length, stderrBytes: result.stderr.length }));
Deno.exit(result.code);
