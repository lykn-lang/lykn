class Example {
  method() {
    const bind = value => typeof value;
    return bind(eval);
  }
}
const instance = new Example();
console.log(instance.method());
