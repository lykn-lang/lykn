class Example {
  method(value = (() => {
    const package = 1;
    return 2;
  })()) {
    return value;
  }
}
