const {value = (() => {
  const package = 1;
  return 2;
})()} = {};
