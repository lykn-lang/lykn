function example() {
  1;
  const package = 2;
  return 3;
}
