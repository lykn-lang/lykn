function example(value = (() => {
  const package = 1;
  return 2;
})()) {
  return value;
}
