const result = ((() => {
  const package = 1;
  return () => 2;
})())();
