const {data: {value = do(bind(package, 1), 2)}} = { data: {} };
