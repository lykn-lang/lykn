function sample() {
  const bind = (a, b) => a === eval;
  return true;
}
console.log(sample());
