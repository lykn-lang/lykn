const lyknIntrinsicArrayIsArray0 = Array.isArray;
const lyknIntrinsicTypeError0 = TypeError;
import {lykn, read, expandExpr} from "/Users/oubiwann/lab/lykn/lang/.worktrees/contract-predicate-lowering/packages/lang/mod.js";
import {validateReservedNames} from "/Users/oubiwann/lab/lykn/lang/.worktrees/contract-predicate-lowering/packages/lang/binding.js";
const home = "/private/tmp/lykn-s03-ic01-cdc-5bdbfe3c";
const worktree = "/Users/oubiwann/lab/lykn/lang/.worktrees/contract-predicate-lowering";
const rows = [];
function invoke(label, executable, argv) {
  if (typeof label !== "string") {
    throw new lyknIntrinsicTypeError0("invoke: arg 'label' expected string, got " + typeof label);
  }
  if (typeof executable !== "string") {
    throw new lyknIntrinsicTypeError0("invoke: arg 'executable' expected string, got " + typeof executable);
  }
  if (!lyknIntrinsicArrayIsArray0(argv)) {
    throw new lyknIntrinsicTypeError0("invoke: arg 'argv' expected array, got " + typeof argv);
  }
  const command = new Deno.Command(executable, { args: argv, cwd: worktree, stdout: "piped", stderr: "piped" });
  const result = command.outputSync();
  Deno.writeFileSync(home + "/probes/" + label + ".stdout", result.stdout);
  Deno.writeFileSync(home + "/probes/" + label + ".stderr", result.stderr);
  const decoder = new TextDecoder();
  const observation = { label: label, executable: executable, argv: argv, code: result.code, stdout: decoder.decode(result.stdout), stderr: decoder.decode(result.stderr) };
  rows.push(observation);
  return observation;
}
const names = Deno.args.length > 0 ? Deno.args : ["function-tail", "computed-callee", "kernel-default", "class-default", "declaration-default", "class-body-call", "macro-fn"];
for (const name of names) {
  const sourcePath = home + "/probes/" + name + ".lykn";
  const source = Deno.readTextFileSync(sourcePath);
  for (const mode of ["checked", "stripped"]) {
    const label = name + "-" + mode;
    const output = home + "/probes/" + label + ".mjs";
    const argv = ["compile", sourcePath, "-o", output];
    if (mode === "stripped") {
      argv.push("--strip-assertions");
    }
    const result = invoke(label, worktree + "/bin/lykn", argv);
    if (result.code === 0) {
      invoke(label + "-runtime", Deno.execPath(), ["run", "--no-config", "--cached-only", "--no-npm", "--no-remote", "--no-prompt", output]);
    }
  }
  invoke(name + "-check", worktree + "/bin/lykn", ["check", sourcePath]);
  try {
    validateReservedNames(read(source));
    rows.push({ label: name + "-public-validation", accepted: true });
  } catch (error) {
    rows.push({ label: name + "-public-validation", accepted: false, message: error.message });
  }
  try {
    const generated = lykn(source);
    const output = home + "/probes/" + name + "-public.mjs";
    Deno.writeTextFileSync(output, generated);
    rows.push({ label: name + "-public", accepted: true });
    invoke(name + "-public-runtime", Deno.execPath(), ["run", "--no-config", "--cached-only", "--no-npm", "--no-remote", "--no-prompt", output]);
  } catch (error) {
    rows.push({ label: name + "-public", accepted: false, message: error.message });
  }
  if (!(name === "macro-fn")) {
    try {
      expandExpr(read(source)[0]);
      rows.push({ label: name + "-expand-expr", accepted: true });
    } catch (error) {
      rows.push({ label: name + "-expand-expr", accepted: false, message: error.message });
    }
  }
}
Deno.writeTextFileSync(home + "/census-results.json", JSON.stringify(rows, null, 2));
console.log(JSON.stringify(rows, null, 2));
