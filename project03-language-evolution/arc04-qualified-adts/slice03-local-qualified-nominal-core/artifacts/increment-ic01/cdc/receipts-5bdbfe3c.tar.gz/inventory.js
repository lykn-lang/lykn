const lyknIntrinsicNumberIsNaN0 = Number.isNaN;
const lyknIntrinsicArrayIsArray0 = Array.isArray;
const lyknIntrinsicTypeError0 = TypeError;
const home = "/private/tmp/lykn-s03-ic01-cdc-5bdbfe3c";
const source = "/Users/oubiwann/lab/lykn/lang/.worktrees/contract-predicate-lowering";
const decoder = new TextDecoder();
const commands = [["git", "status", "--short", "--branch"], ["git", "rev-parse", "HEAD", "HEAD^{tree}"], ["git", "show", "-s", "--format=%B", "HEAD"], ["git", "diff", "--name-only", "3f197340..HEAD"], ["rustc", "--version"], ["cargo", "--version"], ["deno", "--version"], ["shasum", "-a", "256", "target/release/lykn", "bin/lykn"]];
const pins = commands.map(argv => {
  if (!lyknIntrinsicArrayIsArray0(argv)) {
    throw new lyknIntrinsicTypeError0("anonymous: arg 'argv' expected array, got " + typeof argv);
  }
  const command = new Deno.Command(argv[0], { args: argv.slice(1), cwd: source, stdout: "piped", stderr: "piped" });
  const result = command.outputSync();
  return { argv: argv, code: result.code, stdout: decoder.decode(result.stdout), stderr: decoder.decode(result.stderr) };
});
const oldCommand = new Deno.Command("git", { args: ["show", "3f197340:packages/lang/compiler.js"], cwd: source, stdout: "piped", stderr: "piped" });
const oldResult = oldCommand.outputSync();
const oldSource = decoder.decode(oldResult.stdout);
const marker = "const MACRO_OVERRIDES";
const oldConverter = oldSource.slice(oldSource.indexOf(marker), oldSource.indexOf("/** Build a VariableDeclaration"));
const leaf = Deno.readTextFileSync(source + "/packages/lang/identifier.js");
const newConverter = leaf.slice(leaf.indexOf(marker));
const algorithmUnchanged = oldConverter.trim() === newConverter.trim();
function withoutBlankLines(value) {
  if (typeof value !== "string") {
    throw new lyknIntrinsicTypeError0("withoutBlankLines: arg 'value' expected string, got " + typeof value);
  }
  const lines = value.split("\n");
  const nonempty = lines.filter(line => {
    if (typeof line !== "string") {
      throw new lyknIntrinsicTypeError0("anonymous: arg 'line' expected string, got " + typeof line);
    }
    return !(line === "");
  });
  return nonempty.join("\n");
}
const algorithmIgnoringBlankLines = withoutBlankLines(oldConverter.trim()) === withoutBlankLines(newConverter.trim());
const mirrorNames = ["binding.js", "compiler.js", "reserved-words.js", "expander-core.js", "identifier.js"];
const comparisons = mirrorNames.map(name => {
  if (typeof name !== "string") {
    throw new lyknIntrinsicTypeError0("anonymous: arg 'name' expected string, got " + typeof name);
  }
  const canonical = Deno.readFileSync(source + "/packages/lang/" + name);
  const embedded = Deno.readFileSync(source + "/crates/lykn-lang/embedded/packages/lang/" + name);
  return { name: name, bytes: canonical.length, equal: canonical.length === embedded.length && canonical.every((byte, index) => {
    if (typeof byte !== "number" || lyknIntrinsicNumberIsNaN0(byte)) {
      throw new lyknIntrinsicTypeError0("anonymous: arg 'byte' expected number, got " + typeof byte);
    }
    if (typeof index !== "number" || lyknIntrinsicNumberIsNaN0(index)) {
      throw new lyknIntrinsicTypeError0("anonymous: arg 'index' expected number, got " + typeof index);
    }
    return byte === embedded[index];
  }) };
});
const result = { pins: pins, dd49ByteIdentical: algorithmUnchanged, dd49IgnoringBlankLines: algorithmIgnoringBlankLines, mirrorComparisons: comparisons };
Deno.writeTextFileSync(home + "/inventory.json", JSON.stringify(result, null, 2));
console.log(JSON.stringify(result, null, 2));
